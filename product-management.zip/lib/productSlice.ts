"use client"

import { createSlice, type PayloadAction } from "@reduxjs/toolkit"
import type { Product } from "./types"

interface ProductState {
  items: Product[]
}

const initialState: ProductState = {
  items: [
    {
      id: "1",
      name: "Classic T-Shirt",
      price: 29.99,
      category: "Fashion",
      inventory: 25,
    },
    {
      id: "2",
      name: "Denim Jeans",
      price: 59.99,
      category: "Fashion",
      inventory: 15,
    },
    {
      id: "3",
      name: "Wireless Earbuds",
      price: 99.99,
      category: "Technology",
      inventory: 8,
    },
    {
      id: "4",
      name: "Kitchen Blender",
      price: 79.99,
      category: "Household",
      inventory: 4,
    },
  ],
}

export const productSlice = createSlice({
  name: "products",
  initialState,
  reducers: {
    addProduct: (state, action: PayloadAction<Product>) => {
      state.items.push(action.payload)
    },
    deleteProduct: (state, action: PayloadAction<string>) => {
      state.items = state.items.filter((product) => product.id !== action.payload)
    },
    loadProducts: (state, action: PayloadAction<Product[]>) => {
      state.items = action.payload
    },
  },
})

export const { addProduct, deleteProduct, loadProducts } = productSlice.actions

export default productSlice.reducer
