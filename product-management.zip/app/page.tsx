"use client"
import { Provider } from "react-redux"
import ProductManagement from "@/components/ProductManagement"
import { store } from "@/lib/store"

export default function Home() {
  return (
    <Provider store={store}>
      <main className="min-h-screen bg-gray-50">
        <div className="container mx-auto px-4 py-8">
          <h1 className="text-3xl font-bold text-gray-800 mb-6">Outfit Store Management</h1>
          <ProductManagement />
        </div>
      </main>
    </Provider>
  )
}
