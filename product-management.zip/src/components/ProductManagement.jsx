"use client"

import { useState, useEffect } from "react"
import { useDispatch, useSelector } from "react-redux"
import { addProduct, deleteProduct, loadProducts } from "../lib/productSlice"
import ProductForm from "./ProductForm"
import ProductList from "./ProductList"
import ProductStats from "./ProductStats"

export default function ProductManagement() {
  const dispatch = useDispatch()
  const products = useSelector((state) => state.products.items)

  const [searchTerm, setSearchTerm] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("")

  // Load products from localStorage on initial render
  useEffect(() => {
    const savedProducts = localStorage.getItem("products")
    if (savedProducts) {
      dispatch(loadProducts(JSON.parse(savedProducts)))
    }
  }, [dispatch])

  // Save products to localStorage whenever they change
  useEffect(() => {
    localStorage.setItem("products", JSON.stringify(products))
  }, [products])

  // Get unique categories for the filter dropdown
  const categories = ["All", ...new Set(products.map((product) => product.category))]

  // Filter products based on search term and category
  const filteredProducts = products.filter((product) => {
    const matchesSearch = product.name.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesCategory =
      selectedCategory === "" || selectedCategory === "All" || product.category === selectedCategory
    return matchesSearch && matchesCategory
  })

  const handleAddProduct = (product) => {
    dispatch(
      addProduct({
        ...product,
        id: Date.now().toString(),
      }),
    )
  }

  const handleDeleteProduct = (id) => {
    dispatch(deleteProduct(id))
  }

  return (
    <div className="space-y-6">
      <ProductForm onAddProduct={handleAddProduct} />

      <div className="bg-white p-6 rounded-lg shadow-md">
        <div className="flex flex-col md:flex-row gap-4 mb-6">
          <div className="flex-1">
            <label htmlFor="search" className="block text-sm font-medium text-gray-700 mb-1">
              Search Products
            </label>
            <input
              type="text"
              id="search"
              placeholder="Search by name..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>

          <div className="flex-1">
            <label htmlFor="category" className="block text-sm font-medium text-gray-700 mb-1">
              Filter by Category
            </label>
            <select
              id="category"
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              {categories.map((category) => (
                <option key={category} value={category}>
                  {category}
                </option>
              ))}
            </select>
          </div>
        </div>

        <ProductStats products={products} />

        <ProductList products={filteredProducts} onDeleteProduct={handleDeleteProduct} />
      </div>
    </div>
  )
}
