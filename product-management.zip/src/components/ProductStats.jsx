export default function ProductStats({ products }) {
  const totalProducts = products.length
  const totalInventory = products.reduce((sum, product) => sum + product.inventory, 0)

  return (
    <div className="flex items-center justify-between mb-4 p-3 bg-gray-50 rounded-md">
      <div className="text-sm font-medium">
        Total products: <span className="font-bold text-blue-600">{totalProducts}</span>
      </div>
      <div className="text-sm font-medium">
        Total inventory: <span className="font-bold text-blue-600">{totalInventory}</span>
      </div>
    </div>
  )
}
