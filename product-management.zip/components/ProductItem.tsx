"use client"

import { Trash2 } from "lucide-react"
import type { Product } from "@/lib/types"

interface ProductItemProps {
  product: Product
  onDelete: (id: string) => void
}

export default function ProductItem({ product, onDelete }: ProductItemProps) {
  return (
    <tr>
      <td className="px-6 py-4 whitespace-nowrap">
        <div className="text-sm font-medium text-gray-900">{product.name}</div>
      </td>
      <td className="px-6 py-4 whitespace-nowrap">
        <div className="text-sm text-gray-900">${product.price.toFixed(2)}</div>
      </td>
      <td className="px-6 py-4 whitespace-nowrap">
        <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-blue-100 text-blue-800">
          {product.category}
        </span>
      </td>
      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{product.inventory}</td>
      <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
        <button
          onClick={() => onDelete(product.id)}
          className="text-red-600 hover:text-red-900 transition-colors"
          aria-label={`Delete ${product.name}`}
        >
          <Trash2 size={18} />
        </button>
      </td>
    </tr>
  )
}
