"use client"

import type React from "react"

import { useState } from "react"
import { PlusCircle } from "lucide-react"

interface ProductFormProps {
  onAddProduct: (product: {
    name: string
    price: number
    category: string
    inventory: number
  }) => void
}

export default function ProductForm({ onAddProduct }: ProductFormProps) {
  const [name, setName] = useState("")
  const [price, setPrice] = useState("")
  const [category, setCategory] = useState("")
  const [inventory, setInventory] = useState("")

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (!name || !price || !category || !inventory) {
      alert("Please fill in all fields")
      return
    }

    onAddProduct({
      name,
      price: Number.parseFloat(price),
      category,
      inventory: Number.parseInt(inventory),
    })

    // Reset form
    setName("")
    setPrice("")
    setCategory("")
    setInventory("")
  }

  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <h2 className="text-xl font-semibold mb-4">Add New Product</h2>

      <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
            Product Name
          </label>
          <input
            type="text"
            id="name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            placeholder="T-Shirt"
          />
        </div>

        <div>
          <label htmlFor="price" className="block text-sm font-medium text-gray-700 mb-1">
            Price ($)
          </label>
          <input
            type="number"
            id="price"
            value={price}
            onChange={(e) => setPrice(e.target.value)}
            min="0"
            step="0.01"
            className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            placeholder="29.99"
          />
        </div>

        <div>
          <label htmlFor="category" className="block text-sm font-medium text-gray-700 mb-1">
            Category
          </label>
          <input
            type="text"
            id="category"
            value={category}
            onChange={(e) => setCategory(e.target.value)}
            className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            placeholder="Fashion"
            list="category-suggestions"
          />
          <datalist id="category-suggestions">
            <option value="Fashion" />
            <option value="Technology" />
            <option value="Household" />
            <option value="Accessories" />
            <option value="Footwear" />
          </datalist>
        </div>

        <div>
          <label htmlFor="inventory" className="block text-sm font-medium text-gray-700 mb-1">
            Inventory
          </label>
          <input
            type="number"
            id="inventory"
            value={inventory}
            onChange={(e) => setInventory(e.target.value)}
            min="0"
            className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            placeholder="10"
          />
        </div>

        <div className="md:col-span-2">
          <button
            type="submit"
            className="w-full flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-4 rounded-md transition-colors"
          >
            <PlusCircle size={20} />
            Add Product
          </button>
        </div>
      </form>
    </div>
  )
}
